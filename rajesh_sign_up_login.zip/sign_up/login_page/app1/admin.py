from django.contrib import admin

from app1.models import Student

class StudentAdmin(admin.ModelAdmin):
    list_display=["user_name","first_name","last_name","email_field","password1","password2"]
admin.site.register(Student,StudentAdmin)
# Register your models here.
