from django.shortcuts import render
from django.http import HttpRequest,JsonResponse
from rest_framework.views  import APIView 
from rest_framework.renderers import JSONRenderer
from django.views.decorators.csrf import csrf_exempt
from .serializers import StudentSerializer
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
 
import json

class Customer(APIView):
    @csrf_exempt
    def post(self,request):
        # data=json.loads(request.body)
        # data1=request.data
        serializer=StudentSerializer(data=json.loads(request.body))
        #serializer=StudentSerializer(data=data)
        if serializer.is_valid():
        
            
            user_name = serializer.validated_data['user_name']
            password1 = serializer.validated_data['password1']
            email_field=serializer.validated_data['email_field']
           
            #return JsonResponse({"message":"dont match password "})
            created=User.objects.create_user(username=user_name,password=password1,email=email_field)
        
            return JsonResponse({"message":"Account Created successfully"})
            #user_data = serializer.validated_data(['user']
            
    def get(self,request):
        
        #data=json.loads(request.data)
        
        serializer=StudentSerializer(data=request.data)
        if serializer.is_valid():
            user_name = serializer.validated_data['user_name']
            password1 = serializer.validated_data['password1']
            user=authenticate(username=user_name,password=password1)
            
            if user is not None:
                login(request,user)
                return JsonResponse({"message":"successfully login"})
            else:
                return JsonResponse({"message":"please try aggain"})

            

            

# Create your views here.

