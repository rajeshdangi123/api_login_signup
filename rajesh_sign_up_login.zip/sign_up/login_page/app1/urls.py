from django.contrib import admin
from django.urls import path,include
from app1 import views
from .views import Customer

urlpatterns = [
    
    path("api/Customer/",views.Customer.as_view()),
]