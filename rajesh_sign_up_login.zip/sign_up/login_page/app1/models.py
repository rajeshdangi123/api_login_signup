from django.db import models


class Student(models.Model):
    user_name=models.CharField(max_length=30,blank=True,null=True)
    first_name=models.CharField(max_length=20,blank=True,null=True)
    last_name=models.CharField(max_length=20,blank=True,null=True)
    email_field=models.EmailField(blank=True,null=True)
    password1=models.CharField(max_length=30,blank=True,null=True)
    password2=models.CharField(max_length=30,blank=True,null=True)
# Create your models here.
