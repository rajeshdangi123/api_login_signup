from app1.models import Student
from rest_framework import serializers
from django.contrib.auth.models import User


class StudentSerializer(serializers.Serializer):
    user_name=serializers.CharField(max_length=30)
    first_name=serializers.CharField(max_length=20)
    last_name=serializers.CharField(max_length=20)
    email_field=serializers.EmailField()
    password1=serializers.CharField(max_length=30)
    password2=serializers.CharField(max_length=30)
    
    def create(self, validated_data):
        user=User.objects.create_user(validated_data["user_name"],validated_data["first_name"],
                                      validated_data["last_name"],validated_data["email_field"],
                                    validated_data["password1"],validated_data["password2"])
        
        return user
    def  authenticate(self,validated_data):
        user=User.objects.authenticate(validated_data["user_name"],validated_data["password1"])
        return user

class UserSerializer(serializers.Serializer):
    pass    